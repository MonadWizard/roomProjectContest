import grammer_suggestions

a = grammer_suggestions.get_result("we has a pen")
print(a)

